﻿///<summary>
///      File                 : NaukriException.cs
///      Author Name          : Amit Potdar
///      Desc                 : Manual Exceptions implemented
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri.com.Exceptions
{
    public class NaukriException : ApplicationException
    {
        public NaukriException()
            : base()
        {
        }


        public NaukriException(string message)
            : base(message)
        {
        }
        public NaukriException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
