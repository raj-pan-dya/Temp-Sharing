﻿///<summary>
///      File                 : Program.cs
///      Author Name          : Amit Potdar
///      Desc                 : Printing property info of class
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

/*
 * Printing property info of class
 */
namespace Person
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initializing Asssembly object
             Assembly assembly = Assembly.GetExecutingAssembly();

            //to get all the type present in data
            foreach (Type type in assembly.GetTypes())
            {
                //checking if the type name is person or not
                if (type.Name == "Person")
                {
                    //Creating instance and storing
                    object obj = assembly.CreateInstance("Person.Person");

                    PropertyInfo[] property = type.GetProperties();
                    Console.WriteLine("Total Properties N = {0}:",property.Length);
                    foreach (var prop in property)
                        if (prop.GetIndexParameters().Length == 0)
                        {
                            //print type , name and value of properties
                            Console.WriteLine("Name : {0} Type : {1} Value : {2}", prop.Name, prop.PropertyType.Name,prop.GetValue(obj));
                        }
                        else
                            Console.WriteLine("Name : {0} Type : {1}", prop.Name,
                                              prop.PropertyType.Name);

                }
            }
            

            Console.ReadKey();
        }
    }
}
