﻿/*********************************************************************
 * File                 : Customer.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to inherit a class and over ride its method..
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerM2_3
{
     //Inheritence
    class Customer : Person
    {
        private string Address;
        private string City;

        // Main Function
        static void Main(string[] args)
        {
            Customer objCustomer = new Customer();

            Console.WriteLine();

            Console.Write(" Enter the  ID:- ");
            objCustomer.Id = Convert.ToInt32(Console.ReadLine());

            Console.Write(" Enter the Name:- ");
            objCustomer.Name = Console.ReadLine();

            Console.Write(" Enter the Date Of Birth:- ");
            objCustomer.DateOfBirth = Console.ReadLine();

            Console.Write(" Enter the Address:- ");
            objCustomer.Address = Console.ReadLine();

            Console.Write(" Enter the City:- ");
            objCustomer.City= Console.ReadLine();

            Console.WriteLine();

            objCustomer.printDetails();

        }
        
        // Method Over riding
        public override void printDetails()
        {
            Console.WriteLine();
            Console.WriteLine("================= Details=====================");
            Console.WriteLine(" Person ID : " + Id);
            Console.WriteLine(" Person Name : " + Name);
            Console.WriteLine(" Person Age : " + Age);
            Console.WriteLine(" Person Date Of Birth : " + DateOfBirth);
            Console.WriteLine(" Person Address :" + Address);
            Console.WriteLine(" Person City : " + City);

            Console.WriteLine("==============================================");
            Console.WriteLine();
        }
    }


}
