﻿//<Summary>
/*********************************************************************
 * File                 : Program.cs
 * Author Name          : Alamgir Mohammad
 * Desc                 : Program to implement Doctor Management System
                          using layered Architecture.
 * Version              : 1.0
 * Last Modified Date   : 05-Dec-2018
 * Change Description   : Description about the changes implemented
 *********************************************************************/
//</summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem.Exceptions;
using DoctorMgmtSystem.DataAccessLayer;
using DoctorMgmtSystem.BusinessLayer;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DoctorMgmtSystem.PresentationLayer
{
    [Serializable]

    class Program
    {
        static void Main(string[] args)
        {

            int choice;

            do
            {
                printMenu();
                Console.WriteLine();

                Console.Write(" Enter your Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {

                    case 1:
                        //Add a Doctor
                        addDoctor();
                        break;

                    case 2:
                        //List All doctors
                        listAllDoctor();
                        break;

                    case 3:
                        // To search A doctor
                        searchDoctorByRegistrationNumber();
                        break;


                    case 4:
                        //Serialise the Doctor Data
                        SerializeListBF();
                        break;

                   case 5:
                        //Deserialise The Doctor Data
                        DeSerializeListBF();
                        break;

                   case 6: //Exit
                        return;

                    default:
                        Console.WriteLine(" Invalid Choice");
                        break;
                }

            } while (choice != -1);

        }

        // Menu Fuction

        static void printMenu()
        {
            Console.WriteLine();
            Console.WriteLine(" ==================== Menu ====================");
            Console.WriteLine(" 1. Add Doctor");
            Console.WriteLine(" 2. List All Doctor");
            Console.WriteLine(" 3. Search Doctor by Registration Id");
            Console.WriteLine(" 4. Serializable");
            Console.WriteLine(" 5. Deserializable");
            Console.WriteLine(" 6. Exit");
            Console.WriteLine(" ==============================================");
        }

        //Add function

        static void addDoctor()
        {
            try
            {
                Doctor objDoctor = new Doctor();

                // Taking the entries of the doctor

                Console.WriteLine();
                Console.WriteLine(" Enter the Details:- ");
                Console.WriteLine();

                Console.Write(" Enter the Doctor Registration Number:- ");
                objDoctor.DoctRegistraionNumber = Convert.ToInt32(Console.ReadLine());

                Console.Write(" Enter the Doctor Name:- ");
                objDoctor.DoctName = Console.ReadLine();

                Console.Write(" Enter the Doctor City:- ");
                objDoctor.DoctCity = Console.ReadLine();

                Console.Write(" Enter the Doctor Area Of Specialization:- ");
                objDoctor.DoctAreaOfSpecialization = Console.ReadLine();

                Console.Write(" Enter the Doctor Clinic Address:- ");
                objDoctor.DoctClinicAddress = Console.ReadLine();

                Console.Write(" Enter the Doctor Clinic Timings:- ");
                objDoctor.DoctClinincTimings = Convert.ToDateTime(Console.ReadLine());

                Console.Write(" Enter the Doctor Contact Number:- ");
                objDoctor.DoctContactNumber = Console.ReadLine();


                bool doctorAdded;

                doctorAdded = DoctorBL.addDoctorBL(objDoctor);

                if (doctorAdded)
                {
                    Console.Write(" \n\n Doctor added Successfully ");
                    Console.WriteLine();
                }

                else
                {
                    Console.Write(" \n\n Doctor not Added");
                    Console.WriteLine();
                }

            }


            catch (DoctorMgmtSystemException objEmpMgmSystemEx)
            {
                Console.WriteLine(objEmpMgmSystemEx.Message);
            }


        }

       
        // search a doctor

        static void searchDoctorByRegistrationNumber()
        {
            try
            {
                int registrationNo;
                Console.Write(" Enter Registrion Number: ");
                registrationNo = Convert.ToInt32(Console.ReadLine());

                Doctor objDoctor;

                objDoctor = DoctorBL.searchDoctorBL(registrationNo);

                if (objDoctor != null)
                {
                    Console.WriteLine(" Doctor Details:-");
                    Console.WriteLine();
                    Console.WriteLine(" Doctor Registration Number: " + objDoctor.DoctRegistraionNumber);
                    Console.WriteLine(" Doctor Name: " + objDoctor.DoctName);
                    Console.WriteLine(" Doctor City: " + objDoctor.DoctCity);
                    Console.WriteLine(" Doctor Area Of Speicialization: " + objDoctor.DoctAreaOfSpecialization);
                    Console.WriteLine(" Doctor Clinic Address: " + objDoctor.DoctClinicAddress);
                    Console.WriteLine(" Doctor Clinic Timing: " + objDoctor.DoctClinincTimings);
                    Console.WriteLine(" Doctor Contact Number: " + objDoctor.DoctContactNumber);

                }

                else
                {
                    Console.WriteLine(" Employee Data couldn't be found");
                }
            }
            catch (DoctorMgmtSystemException objMgmSystemEx)
            {
                Console.WriteLine(objMgmSystemEx.Message);
            }


        }

        // List all Doctors
     
        static void listAllDoctor()
        {
            try
            {
                List<Doctor> doctorList = DoctorBL.getAllDoctorBL();

                if (doctorList != null)
                {
                    Console.WriteLine();
                    Console.WriteLine(" ============================================================================================================");
                    Console.WriteLine("  Doctor_Reg_No\t\tDoctorNameName\t\tDoctorCity\t\tDoctorSpecialisation\t\tDoctorAddress\t\tTimings\t\tContactNumber");
                    Console.WriteLine(" =============================================================================================================");


                    foreach (Doctor doctor in doctorList)
                    {
                        Console.WriteLine(" {0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t{5}\t\t{6}", doctor.DoctRegistraionNumber, doctor.DoctName, doctor.DoctCity, 
                            doctor.DoctAreaOfSpecialization,doctor.DoctClinicAddress,doctor.DoctClinincTimings,doctor.DoctContactNumber);
                    }
                    Console.WriteLine(" ===========================================================================================================");

                }
                else
                {
                    Console.WriteLine(" No Doctor Details Available");
                }
            }
            catch (DoctorMgmtSystemException objEmpMgmSystemEx)
            {
                Console.WriteLine(objEmpMgmSystemEx.Message);
            }
        }


        //Serializing Contact list using Binary Formatter 
        public static void SerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\m13\Desktop\Alam\DoctorListBF.txt", FileMode.Create);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(stream, DoctorDAL.objDoctorList);
            stream.Close();
        }

        
        //DeSerializing Contact list using Binary Formatter 
        public static List<Doctor> DeSerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\m13\Desktop\Alam\DoctorListBF.txt", FileMode.Open);
            BinaryFormatter bin = new BinaryFormatter();
            DoctorDAL.objDoctorList1 = bin.Deserialize(stream) as List<Doctor>;
            stream.Close();
            return DoctorDAL.objDoctorList1;

        }

    }
    }

