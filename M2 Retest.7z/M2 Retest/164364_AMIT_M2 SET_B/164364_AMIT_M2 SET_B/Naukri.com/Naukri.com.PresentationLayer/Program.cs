﻿///<summary>
///      File                 :  Program.cs
///      Author Name          : Amit Potdar
///      Desc                 : Program to design Console Application and display the required output.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.com.Entities;
using Naukri.com.Exceptions;
using Naukri.com.BusinessLayer;
using Naukri.com.DataAccessLayer;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Naukri.com.PresentationLayer
{
    class Program
    {
        // Main Fuction.

        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine();
                Console.Write(" Enter your Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddJobSeeker();
                        break;
                    case 2:
                        SearchByCity();
                        break;
       
                    case 3:
                        SerializeListBF();
                        break;
                    case 4:
                        DeSerializeListBF();
                        break;
                    case 5:
                        return;


                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

        //Function to display Menu.

        private static void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine("\n ================== Naukri.Com Portal  ==================== ");
            Console.WriteLine(" 1. Add a JobSeeker");
  
            Console.WriteLine(" 2. Search JobSeeker by City");
            Console.WriteLine(" 3. Serialize List");
            Console.WriteLine(" 4. Deserialize List");
            Console.WriteLine(" 5. Exit");
            Console.WriteLine(" ============================================================\n");
        }
        private static void AddJobSeeker()
        {
            try
            {
                JobSeekers newJS = new JobSeekers();
                Console.WriteLine();
                Console.WriteLine("Job Seeker Entry:");
                Console.WriteLine();
                Console.Write(" Enter Name : ");
                newJS.Name= Console.ReadLine();
                Console.Write(" Enter Qualification: ");
                newJS.Qualification = Console.ReadLine();
                Console.Write(" Enter Mobile : ");
                newJS.Mobile = Convert.ToInt32( Console.ReadLine());
                Console.Write(" Enter City ");
                newJS.City = Console.ReadLine();
                Console.Write(" Enter DOB ");
                //newJS.DOB = System.DateTime(Console.ReadLine());
                Console.WriteLine();
   
                bool jsAdded = NaukriBL.AddJS(newJS);

                if (jsAdded)
                    Console.WriteLine(" User Added");
                else
                    Console.WriteLine(" User not Added");
            }
            catch (NaukriException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SearchByCity()
        {
            try
            {
               

                string city;
                Console.WriteLine();
                Console.Write(" Enter City of user to Search: ");
                city = Console.ReadLine();

               
                    List<JobSeekers> searchJS = NaukriBL.SearchByCityBL(city);
                    if (searchJS.Count != 0)
                    {
                        Console.WriteLine();
                        Console.WriteLine(" ========================================================================================");
                        Console.WriteLine(" Name\t\tQualification\t\tMobile\t\tCity\t\tDOB");
                        Console.WriteLine(" ========================================================================================");
                        foreach (JobSeekers jobseekers in searchJS)
                        {
                            Console.WriteLine(" {0}\t\t{1}\t\t{2}\t\t\t{3}\t\t\t{4}\t\t\t{5}", jobseekers.Name, jobseekers.Qualification, jobseekers.Mobile, jobseekers.City, jobseekers.DOB);
                        }
                        Console.WriteLine(" ========================================================================================");
                    
                }
                else
                {
                    Console.WriteLine(" No User Details Available");
                }
            }
            catch (NaukriException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine();
        }
        static List<JobSeekers> jobSeekers = new List<JobSeekers>();

        //DeSerializing JobSeeker list using Binary Formatter 
        public static void SerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\ampotdar\Documents\C#\Assignments\New folder\Lab_13\Lab_13_1 & Lab_13_2\ContactListBF.dat", FileMode.Create);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(stream, NaukriDAL.jobSeekers);
            Console.WriteLine("List of Job Seeker is serialized");
            stream.Close();
        }


        //DeSerializing JobSeeker list using Binary Formatter 
        public static List<JobSeekers> DeSerializeListBF()
        {
            FileStream stream = new FileStream(@"C:\Users\ampotdar\Documents\C#\Assignments\New folder\Lab_13\Lab_13_1 & Lab_13_2\ContactListBF.dat", FileMode.Open);
            BinaryFormatter bin = new BinaryFormatter();
           jobSeekers = bin.Deserialize(stream) as List<JobSeekers>;
            Console.WriteLine(" Deserialized List object");
            stream.Close();
            return jobSeekers;

        }
    }

}

