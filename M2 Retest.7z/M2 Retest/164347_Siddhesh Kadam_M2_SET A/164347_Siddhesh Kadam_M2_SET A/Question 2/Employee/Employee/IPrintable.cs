﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    interface IPrintable
    {
        //Defining a method as stated in question
        void Print();
    }
}
