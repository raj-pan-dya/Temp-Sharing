﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeMgmtSystem.Entities;//imp
using EmployeeMgmtSystem.Exceptions;//imp
using EmployeeMgmtSystem.DataAccessLayer;//imp

namespace EmployeeMgmtSystem.BusinessLayer
{
    public class EmployeeBL
    {

        private static bool ValidateEmployee(Employee objEmployee)
        {
            StringBuilder objSB = new StringBuilder();
            bool validEmployee = true;
            if (objEmployee.Id <= 0)
            {
                validEmployee = false;
                objSB.Append(Environment.NewLine + "InvaliD Employee ID");

            }
            if (objEmployee.Name == string.Empty)
            {
                validEmployee = false;
                objSB.Append(Environment.NewLine + "Employee Name cant be empty");
            }
            if (objEmployee.DesignationId.ToString().Length < 4)
            {
                validEmployee = false;
                objSB.Append(Environment.NewLine + "Required 4 Digit Designation ID");
            }
            if (objEmployee.DepartmentId.ToString().Length < 4)
            {
                validEmployee = false;
                objSB.Append(Environment.NewLine + "Required 4 Digit Department ID");
            }
            if (validEmployee == false)
                throw new EmployeeMgmtSystemException(objSB.ToString());
            return validEmployee;
        }

        public static bool AddEmployeeBL(Employee objEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(objEmployee))
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();//responsible for manipulating collection and maintain the same.
                    objEmployeeDAL.AddEmployeeDAL(objEmployee);
                }
            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;

            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeAdded;
        }

        public static Employee SearchEmployeeBL(int id)
        {
            Employee objEmployee;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objEmployee = objEmployeeDAL.SearchEmployeeDAL(id);

            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }

            return objEmployee;

        }

        public static bool UpdateEmployeeBL(Employee objEmployee)
        {
            bool employeeUpdated = false;


            try
            {
                if (ValidateEmployee(objEmployee))
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeUpdated = objEmployeeDAL.UpdateEmployeeDAL(objEmployee);
                }
            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeUpdated;
        }


        public static bool DeleteEmployeeBL(int id)
        {
            bool employeeDeleted = false;
            try
            {
                if (id > 0)//dont pass to validateEmployee() as it checks everything so write seperate validation
                {


                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeDeleted = objEmployeeDAL.DeleteEmployeeDAL(id);
                }
                else
                {
                    throw new EmployeeMgmtSystemException("Invalid Employee Id.");
                }

            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeDeleted;
        }

        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> objEmployeList = null;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objEmployeList = objEmployeeDAL.GetAllEmployeeDAL();
            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objEmployeList;

        }

    }
}
