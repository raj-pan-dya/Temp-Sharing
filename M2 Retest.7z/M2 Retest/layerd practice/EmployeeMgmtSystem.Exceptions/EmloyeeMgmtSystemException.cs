﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeMgmtSystem.Exceptions
{
    public class EmployeeMgmtSystemException:ApplicationException
    {
        public EmployeeMgmtSystemException()
            :base()
        {

        }

        public EmployeeMgmtSystemException(string message) 
            : base(message)
        {

        }

        public EmployeeMgmtSystemException(string message,Exception objEx) 
            : base(message,objEx)
        {

        }

    }
}
