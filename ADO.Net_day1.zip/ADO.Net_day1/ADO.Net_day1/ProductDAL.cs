﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace ADO.Net_day1
{
    public class ProductDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ProductDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }
        public void Insert(Product product)
        {
            try
            {
               // cmd = new SqlCommand("insert into Amit.Product values (@pName,@price,@eDate)",con );
                cmd = new SqlCommand("Amit.USP_ProductInsert", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pname",product.ProdName );
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            //catch (UDException ex1)
            //{

            //}
            catch (Exception ex2)
            {

            }
            finally
            {
                if(con.State == System.Data.ConnectionState.Open)
                  con.Close();
            }

        }
        public IEnumerable<Product> SelectAllMem()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand("select * from Amit.Product", con);
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return products;
        }
        public void Update(Product product)
        {
            try
            {
                // cmd = new SqlCommand("insert into Amit.Product values (@pName,@price,@eDate)",con );
                cmd = new SqlCommand("Amit.USP_ProductUpdate", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);

                cmd.Parameters.AddWithValue("@pname", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                con.Open();
                cmd.ExecuteNonQuery();
            }
          
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }

        }
        public void Delete(int id)
        {
            try
            {
                cmd = new SqlCommand("Amit.USP_ProductDelete", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id",id);
                con.Open();
                cmd.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }

        }

    }
}
