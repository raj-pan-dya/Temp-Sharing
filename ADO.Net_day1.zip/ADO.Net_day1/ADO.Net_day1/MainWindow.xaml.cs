﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ADO.Net_day1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        ProductDAL prDal = new ProductDAL();
        public void PopulateUI()
        {
            IEnumerable<Product> prods = prDal.SelectAllMem();
            gridProducts.ItemsSource = prods;
            prodList.ItemsSource = prods;
            prodList.DisplayMemberPath = "ProdName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }
        private void Btn_insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product pro = new Product
                {
                    ProdName = prodList.Text,
                    Price = Convert.ToDecimal(price.Text),
                    ExpDate = Convert.ToDateTime(date.Text)

                };
                prDal.Insert(pro);
                MessageBox.Show("Inserted Succesfully");
                PopulateUI();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }
        

        private void Btn_update_Click(object sender, RoutedEventArgs e)
        {
                    
            
            try
            {
                Product pTemp = (Product)prodList.SelectedItem;
                pTemp.ProdName = prodList.Text;
                pTemp.Price = Convert.ToDecimal(price.Text);
                pTemp.ExpDate = Convert.ToDateTime(date.Text);         
                
                prDal.Update(pTemp);
                MessageBox.Show("Updated Succesfully");
                PopulateUI();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void Btn_delete_Click(object sender, RoutedEventArgs e)
        {
            Product pTemp = (Product)prodList.SelectedItem;

            try
            {
                

                prDal.Delete(pTemp.Id);
                MessageBox.Show("Deleted Succesfully");

                PopulateUI();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void ProdList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}
